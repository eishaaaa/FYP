import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import 'user_screens.dart';
import 'supplier_screens.dart';

final auth = FirebaseAuth.instance;
final db = FirebaseFirestore.instance;

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  Future<void> _complete(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding', true);
    if (!context.mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SplashScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return IntroductionScreen(
      pages: [
        PageViewModel(
          title: "Secure Ownership of Land & Electronics",
          body: "Verify authenticity with QR codes",
          image: const Icon(Icons.security, size: 150, color: Colors.green),
        ),
        PageViewModel(
          title: "Verify Authenticity with QR Codes",
          body: "Scan to confirm ownership instantly",
          image: const Icon(Icons.qr_code_scanner, size: 150, color: Colors.green),
        ),
        PageViewModel(
          title: "Invest in Real Assets (Coming Soon)",
          body: "Tokenization & NFTs in Phase 2",
          image: const Icon(Icons.token, size: 150, color: Colors.green),
        ),
      ],
      done: const Text("Get Started", style: TextStyle(fontWeight: FontWeight.bold)),
      onDone: () => _complete(context),
      showSkipButton: true,
      skip: const Text("Skip"),
      next: const Icon(Icons.arrow_forward),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), _navigate);
  }

  void _navigate() async {
    final user = auth.currentUser;
    if (user == null) {
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
      return;
    }
    final doc = await db.collection('users').doc(user.uid).get();
    final role = doc['role'] ?? 'user';
    if (!mounted) return;
    if (role == 'user') {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const UserHomeScreen()));
    } else {
      final type = role.contains('land') ? 'land' : 'electronics';
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SupplierHomeScreen(type: type)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.eco, size: 80, color: Colors.white),
            SizedBox(height: 16),
            Text('Digital Goods',
                style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String _role = 'user';
  bool _loading = false;

  Future<void> _login() async {
    setState(() => _loading = true);
    try {
      await auth.signInWithEmailAndPassword(email: _emailCtrl.text.trim(), password: _passCtrl.text);
      final user = auth.currentUser!;
      final doc = await db.collection('users').doc(user.uid).get();
      final role = doc['role'] ?? 'user';
      if (!mounted) return;
      if (role == 'user') {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const UserHomeScreen()));
      } else {
        final type = role.contains('land') ? 'land' : 'electronics';
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SupplierHomeScreen(type: type)));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login failed: $e')));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Login', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ChoiceChip(
                    label: const Text('User'), selected: _role == 'user', onSelected: (_) => setState(() => _role = 'user')),
                const SizedBox(width: 10),
                ChoiceChip(
                    label: const Text('Supplier'), selected: _role == 'supplier', onSelected: (_) => setState(() => _role = 'supplier')),
              ],
            ),
            const SizedBox(height: 20),
            TextField(controller: _emailCtrl, decoration: const InputDecoration(labelText: 'Email'), keyboardType: TextInputType.emailAddress),
            TextField(controller: _passCtrl, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
            const SizedBox(height: 20),
            _loading ? const CircularProgressIndicator() : ElevatedButton(onPressed: _login, child: const Text('Login')),
            TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())), child: const Text('Register')),
            TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ForgotPasswordScreen())), child: const Text('Forgot Password?')),
          ],
        ),
      ),
    );
  }
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  final _companyCtrl = TextEditingController();
  final _cnicCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();

  String _role = 'user';
  String _supplierType = 'land';
  Uint8List? _photo;
  bool _loading = false;

  Future<void> _pickPhoto() async {
    final status = await Permission.photos.request();
    if (!status.isGranted) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery);
    if (file != null) {
      final bytes = await file.readAsBytes();
      setState(() => _photo = bytes);
    }
  }

  Future<void> _register() async {
    if (_passCtrl.text != _confirmCtrl.text) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Passwords do not match')));
      return;
    }
    setState(() => _loading = true);
    try {
      final cred = await auth.createUserWithEmailAndPassword(email: _emailCtrl.text.trim(), password: _passCtrl.text);
      final uid = cred.user!.uid;
      final data = <String, dynamic>{
        'uid': uid,
        'name': _nameCtrl.text,
        'email': _emailCtrl.text,
        'phone': _phoneCtrl.text,
        'role': _role == 'user' ? 'user' : 'supplier_$_supplierType',
        'createdAt': FieldValue.serverTimestamp(),
      };
      if (_role == 'supplier') {
        data.addAll({
          'company': _companyCtrl.text,
          'cnic': _cnicCtrl.text,
          'city': _cityCtrl.text,
        });
      }
      if (_photo != null) data['photo'] = _photo!;
      await db.collection('users').doc(uid).set(data);
      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          Row(
            children: [
              ChoiceChip(label: const Text('User'), selected: _role == 'user', onSelected: (_) => setState(() => _role = 'user')),
              const SizedBox(width: 10),
              ChoiceChip(label: const Text('Supplier'), selected: _role == 'supplier', onSelected: (_) => setState(() => _role = 'supplier')),
            ],
          ),
          if (_role == 'supplier') ...[
            const SizedBox(height: 10),
            Row(
              children: [
                ChoiceChip(label: const Text('Land'), selected: _supplierType == 'land', onSelected: (_) => setState(() => _supplierType = 'land')),
                const SizedBox(width: 10),
                ChoiceChip(label: const Text('Electronics'), selected: _supplierType == 'electronics', onSelected: (_) => setState(() => _supplierType = 'electronics')),
              ],
            ),
          ],
          const SizedBox(height: 20),
          TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Name')),
          TextField(controller: _emailCtrl, decoration: const InputDecoration(labelText: 'Email')),
          TextField(controller: _phoneCtrl, decoration: const InputDecoration(labelText: 'Phone')),
          TextField(controller: _passCtrl, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
          TextField(controller: _confirmCtrl, decoration: const InputDecoration(labelText: 'Confirm Password'), obscureText: true),
          if (_role == 'supplier') ...[
            TextField(controller: _companyCtrl, decoration: const InputDecoration(labelText: 'Company/Brand')),
            TextField(controller: _cnicCtrl, decoration: const InputDecoration(labelText: 'CNIC/NTN')),
            TextField(controller: _cityCtrl, decoration: const InputDecoration(labelText: 'City')),
          ],
          const SizedBox(height: 20),
          ElevatedButton.icon(onPressed: _pickPhoto, icon: const Icon(Icons.photo), label: const Text('Profile Photo')),
          const SizedBox(height: 20),
          _loading ? const CircularProgressIndicator() : ElevatedButton(onPressed: _register, child: const Text('Register')),
        ]),
      ),
    );
  }
}

// Fixed: Controllers moved outside build
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reset Password')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          TextField(controller: _emailCtrl, decoration: const InputDecoration(labelText: 'Email')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () async {
              await auth.sendPasswordResetEmail(email: _emailCtrl.text.trim());
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reset email sent')));
            },
            child: const Text('Send Reset Link'),
          ),
        ]),
      ),
    );
  }
}