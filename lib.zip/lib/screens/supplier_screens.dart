import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:uuid/uuid.dart';

import 'shared_screens.dart';

final db = FirebaseFirestore.instance;
final auth = FirebaseAuth.instance;

class SupplierHomeScreen extends StatefulWidget {
  final String type;
  const SupplierHomeScreen({super.key, required this.type});

  @override
  State<SupplierHomeScreen> createState() => _SupplierHomeScreenState();
}

class _SupplierHomeScreenState extends State<SupplierHomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.type.capitalize()} Supplier')),
      body: DefaultTabController(
        length: 2,
        child: Column(children: [
          const TabBar(
            tabs: [
              Tab(text: 'Dashboard'),
              Tab(text: 'Assets'),
            ],
          ),
          const SizedBox(height: 10),
          Expanded(
            child: TabBarView(
              children: [
                SupplierDashboard(uid: auth.currentUser!.uid),
                AssetManagementScreen(type: widget.type),
              ],
            ),
          ),
        ]),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => AddAssetScreen(type: widget.type),
          ),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class SupplierDashboard extends StatelessWidget {
  final String uid;
  const SupplierDashboard({super.key, required this.uid});

  Widget _dashboardCard(String title, IconData icon, int value) {
    return Card(
      elevation: 2,
      child: ListTile(
        leading: Icon(icon, size: 32),
        title: Text(title),
        trailing: Text(
          '$value',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          StreamBuilder<QuerySnapshot>(
            stream: db
                .collection('assets')
                .where('ownerId', isEqualTo: uid)
                .snapshots(),
            builder: (context, snapshot) {
              final count = snapshot.data?.docs.length ?? 0;
              return _dashboardCard('Total Assets', Icons.list, count);
            },
          ),

          StreamBuilder<QuerySnapshot>(
            stream: db
                .collection('assets')
                .where('ownerId', isEqualTo: uid)
                .snapshots(),
            builder: (context, snapshot) {
              final views = snapshot.data?.docs.fold<int>(
                0,
                    (sum, d) => sum + (d.data().toString().contains('views')
                    ? (d['views'] as int? ?? 0)
                    : 0),
              ) ??
                  0;

              return _dashboardCard('Total Views', Icons.visibility, views);
            },
          ),

          StreamBuilder<QuerySnapshot>(
            stream: db
                .collection('assets')
                .where('ownerId', isEqualTo: uid)
                .snapshots(),
            builder: (context, snapshot) {
              final verifs = snapshot.data?.docs.fold<int>(
                0,
                    (sum, d) =>
                sum +
                    (d.data().toString().contains('verifications')
                        ? (d['verifications'] as int? ?? 0)
                        : 0),
              ) ??
                  0;

              return _dashboardCard(
                  'Total Verifications', Icons.verified, verifs);
            },
          ),
        ],
      ),
    );
  }
}

class AssetManagementScreen extends StatelessWidget {
  final String type;
  const AssetManagementScreen({super.key, required this.type});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: db
          .collection('assets')
          .where('ownerId', isEqualTo: auth.currentUser!.uid)
          .where('category', isEqualTo: type)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return const Center(child: Text('No assets added yet.'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: docs.length,
          itemBuilder: (context, i) {
            final data = docs[i].data()! as Map<String, dynamic>;
            return Card(
              child: ListTile(
                leading: data['images'] != null &&
                    data['images'].isNotEmpty &&
                    data['images'][0] != null
                    ? Image.memory(
                  base64Decode(data['images'][0]),
                  width: 50,
                  fit: BoxFit.cover,
                )
                    : const Icon(Icons.image),
                title: Text(data['title']),
                subtitle: Text('PKR ${data['price']}'),
                trailing: PopupMenuButton(
                  onSelected: (v) {
                    if (v == 'edit') {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => EditAssetScreen(
                            assetId: docs[i].id,
                            type: type,
                          ),
                        ),
                      );
                    } else if (v == 'delete') {
                      db.collection('assets').doc(docs[i].id).delete();
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('Edit')),
                    PopupMenuItem(value: 'delete', child: Text('Delete')),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class AddAssetScreen extends StatefulWidget {
  final String type;
  const AddAssetScreen({super.key, required this.type});

  @override
  State<AddAssetScreen> createState() => _AddAssetScreenState();
}

class _AddAssetScreenState extends State<AddAssetScreen> {
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _plotCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _brandCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _serialCtrl = TextEditingController();
  final _warrantyCtrl = TextEditingController();

  final List<Uint8List> _images = [];
  String? _docBase64;
  String _condition = 'new';

  Future<void> _pickImages() async {
    final picker = ImagePicker();
    final files = await picker.pickMultiImage();

    for (final f in files) {
      _images.add(await f.readAsBytes());
    }

    setState(() {});
  }

  Future<void> _pickDoc() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null && result.files.single.bytes != null) {
      _docBase64 = base64Encode(result.files.single.bytes!);
    }
  }

  Future<void> _submit() async {
    final id = const Uuid().v4();

    final data = {
      'assetId': id,
      'ownerId': auth.currentUser!.uid,
      'title': _titleCtrl.text,
      'description': _descCtrl.text,
      'price': double.tryParse(_priceCtrl.text) ?? 0,
      'category': widget.type,
      'images': _images.map(base64Encode).toList(),
      'document': _docBase64,
      'createdAt': FieldValue.serverTimestamp(),
      'verified': false,
      'views': 0,
      'verifications': 0,
      'searchKeywords': _titleCtrl.text.toLowerCase().split(' '),
    };

    if (widget.type == 'land') {
      data.addAll({
        'plotArea': _plotCtrl.text,
        'city': _cityCtrl.text,
      });
    } else {
      data.addAll({
        'brand': _brandCtrl.text,
        'model': _modelCtrl.text,
        'serial': _serialCtrl.text,
        'warranty': _warrantyCtrl.text,
        'condition': _condition,
      });
    }

    await db.collection('assets').doc(id).set(data);

    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Asset')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
                controller: _titleCtrl,
                decoration: const InputDecoration(labelText: 'Title')),
            TextField(
                controller: _descCtrl,
                decoration:
                const InputDecoration(labelText: 'Description'),
                maxLines: 3),
            TextField(
                controller: _priceCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Price')),

            if (widget.type == 'land') ...[
              TextField(
                controller: _plotCtrl,
                decoration:
                const InputDecoration(labelText: 'Plot Area'),
              ),
              TextField(
                controller: _cityCtrl,
                decoration: const InputDecoration(labelText: 'City'),
              ),
            ],

            if (widget.type != 'land') ...[
              TextField(
                  controller: _brandCtrl,
                  decoration: const InputDecoration(labelText: 'Brand')),
              TextField(
                  controller: _modelCtrl,
                  decoration: const InputDecoration(labelText: 'Model')),
              TextField(
                  controller: _serialCtrl,
                  decoration:
                  const InputDecoration(labelText: 'Serial / IMEI')),
              TextField(
                  controller: _warrantyCtrl,
                  decoration:
                  const InputDecoration(labelText: 'Warranty (months)')),
              DropdownButtonFormField<String>(
                value: _condition,
                items: const [
                  DropdownMenuItem(value: 'new', child: Text('New')),
                  DropdownMenuItem(value: 'used', child: Text('Used')),
                ],
                onChanged: (v) => setState(() => _condition = v!),
              )
            ],

            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: _pickImages,
              icon: const Icon(Icons.image),
              label: const Text('Pick Images'),
            ),
            ElevatedButton.icon(
              onPressed: _pickDoc,
              icon: const Icon(Icons.attach_file),
              label: const Text('Attach PDF'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submit,
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}

class EditAssetScreen extends StatefulWidget {
  final String assetId;
  final String type;

  const EditAssetScreen({
    super.key,
    required this.assetId,
    required this.type,
  });

  @override
  State<EditAssetScreen> createState() => _EditAssetScreenState();
}

class _EditAssetScreenState extends State<EditAssetScreen> {
  Map<String, dynamic>? _data;
  bool _loading = true;

  Future<void> _load() async {
    final doc = await db.collection('assets').doc(widget.assetId).get();

    setState(() {
      _data = doc.data()!;
      _loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Asset')),
      body: const Center(
        child: Text('Edit screen (to be implemented)'),
      ),
    );
  }
}

extension _StringExt on String {
  String capitalize() => isEmpty
      ? this
      : this[0].toUpperCase() + substring(1);
}
