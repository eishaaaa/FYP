import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'shared_screens.dart';

final db = FirebaseFirestore.instance;
final auth = FirebaseAuth.instance;

class UserRootScreen extends StatefulWidget {
  const UserRootScreen({super.key});
  @override
  State<UserRootScreen> createState() => _UserRootScreenState();
}

class _UserRootScreenState extends State<UserRootScreen> {
  int _selectedIndex = 0;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      const UserHomeScreen(),
      const QRScannerScreen(),
      const MyAssetsScreen(),
      const ProfileScreen(),
    ];
  }

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _selectedIndex, children: _pages),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.qr_code_scanner), label: 'Scan'),
          BottomNavigationBarItem(icon: Icon(Icons.inventory), label: 'My Assets'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class UserHomeScreen extends StatefulWidget {
  const UserHomeScreen({super.key});
  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  final _searchCtrl = TextEditingController();
  String _category = 'land';
  double _minPrice = 0, _maxPrice = 10000000;
  String _city = '', _brand = '', _condition = '';

  Query _buildQuery() {
    var q = db.collection('assets').where('category', isEqualTo: _category);
    if (_minPrice > 0) q = q.where('price', isGreaterThanOrEqualTo: _minPrice);
    if (_maxPrice < 10000000) q = q.where('price', isLessThanOrEqualTo: _maxPrice);
    if (_city.isNotEmpty) q = q.where('city', isEqualTo: _city);
    if (_brand.isNotEmpty) q = q.where('brand', isEqualTo: _brand);
    if (_condition.isNotEmpty) q = q.where('condition', isEqualTo: _condition);
    if (_searchCtrl.text.isNotEmpty) {
      final kw = _searchCtrl.text.toLowerCase();
      q = q.where('searchKeywords', arrayContains: kw);
    }
    return q.orderBy('createdAt', descending: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
            controller: _searchCtrl,
            decoration: const InputDecoration(hintText: 'Search...', border: InputBorder.none),
            onChanged: (_) => setState(() {})),
        bottom: TabBar(
          onTap: (i) => setState(() => _category = i == 0 ? 'land' : 'electronics'),
          tabs: const [Tab(text: 'Land'), Tab(text: 'Electronics')],
        ),
      ),
      body: Column(children: [
        ExpansionTile(
          title: const Text('Filters'),
          children: [
            RangeSlider(
                values: RangeValues(_minPrice, _maxPrice),
                min: 0,
                max: 10000000,
                onChanged: (v) => setState(() {
                  _minPrice = v.start;
                  _maxPrice = v.end;
                })),
            Wrap(
                children: ['Lahore', 'Karachi', 'Islamabad']
                    .map((c) => FilterChip(
                    label: Text(c),
                    selected: _city == c,
                    onSelected: (s) => setState(() => _city = s ? c : '')))
                    .toList()),
            if (_category == 'electronics') ...[
              Wrap(
                  children: ['Samsung', 'Apple']
                      .map((b) => FilterChip(
                      label: Text(b),
                      selected: _brand == b,
                      onSelected: (s) => setState(() => _brand = s ? b : '')))
                      .toList()),
              Wrap(
                  children: ['New', 'Used']
                      .map((c) => FilterChip(
                      label: Text(c),
                      selected: _condition == c.toLowerCase(),
                      onSelected: (s) => setState(() => _condition = s ? c.toLowerCase() : '')))
                      .toList()),
            ],
          ],
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: _buildQuery().snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snapshot.data!.docs;
              if (docs.isEmpty) return const Center(child: Text('No assets found'));
              return GridView.builder(
                padding: const EdgeInsets.all(12),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, childAspectRatio: 0.75, mainAxisSpacing: 12, crossAxisSpacing: 12),
                itemCount: docs.length,
                itemBuilder: (context, i) {
                  final data = docs[i].data()! as Map<String, dynamic>;
                  return GestureDetector(
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => AssetDetailScreen(assetId: docs[i].id))),
                    child: Card(
                      child: Column(children: [
                        Expanded(
                            child: data['images'] != null && data['images'].isNotEmpty
                                ? Image.memory(base64Decode(data['images'][0]), fit: BoxFit.cover)
                                : const Icon(Icons.image)),
                        Padding(
                            padding: const EdgeInsets.all(8),
                            child: Column(children: [
                              Text(data['title'] ?? ''),
                              Text('PKR ${data['price'] ?? 0}'),
                            ])),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}