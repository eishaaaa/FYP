import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:uuid/uuid.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'auth_screens.dart';

final db = FirebaseFirestore.instance;
final auth = FirebaseAuth.instance;

class AssetDetailScreen extends StatelessWidget {
  final String assetId;
  const AssetDetailScreen({super.key, required this.assetId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Asset Detail')),
      body: FutureBuilder<DocumentSnapshot>(
        future: db.collection('assets').doc(assetId).get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final data = snapshot.data!.data()! as Map<String, dynamic>;
          db.collection('assets').doc(assetId).update({'views': FieldValue.increment(1)});
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              if (data['images'] != null && data['images'].isNotEmpty)
                CarouselSlider(
                    items: data['images'].map<Widget>((b64) => Image.memory(base64Decode(b64))).toList(),
                    options: CarouselOptions(height: 200, autoPlay: true)),
              const SizedBox(height: 16),
              Text(data['title'] ?? '', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              Text('PKR ${data['price'] ?? 0}', style: const TextStyle(fontSize: 18, color: Colors.green)),
              Text(data['description'] ?? ''),
              if (data['category'] == 'land') ...[
                Text('Plot: ${data['plotArea'] ?? ''}'),
                Text('City: ${data['city'] ?? ''}'),
              ],
              if (data['category'] == 'electronics') ...[
                Text('Brand: ${data['brand'] ?? ''}'),
                Text('Condition: ${data['condition'] ?? ''}'),
              ],
              if (data['document'] != null)
                ElevatedButton.icon(
                    onPressed: () async {
                      final dir = await getTemporaryDirectory();
                      final file = File('${dir.path}/doc.pdf');
                      await file.writeAsBytes(base64Decode(data['document']));
                      Navigator.push(context, MaterialPageRoute(builder: (_) => PDFViewerScreen(file: file)));
                    },
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('View Document')),
              const SizedBox(height: 12),
              Center(child: QrImageView(data: 'asset://$assetId', size: 140)),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: () => _requestBuy(context, assetId, data['ownerId']), child: const Text('Request to Buy')),
            ]),
          );
        },
      ),
    );
  }

  void _requestBuy(BuildContext ctx, String assetId, String sellerId) async {
    final txId = const Uuid().v4();
    await db.collection('transactions').doc(txId).set({
      'transactionId': txId,
      'assetId': assetId,
      'buyerId': auth.currentUser!.uid,
      'sellerId': sellerId,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Request Sent')));
  }
}

class QRScannerScreen extends StatefulWidget {
  const QRScannerScreen({super.key});
  @override
  State<QRScannerScreen> createState() => _QRScannerScreenState();
}

class _QRScannerScreenState extends State<QRScannerScreen> {
  final _controller = MobileScannerController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan QR')),
      body: MobileScanner(
        controller: _controller,
        onDetect: (capture) {
          final code = capture.barcodes.first.rawValue;
          if (code != null && code.startsWith('asset://')) {
            final id = code.split('://')[1];
            db.collection('assets').doc(id).update({'verifications': FieldValue.increment(1)});
            Navigator.push(context, MaterialPageRoute(builder: (_) => AssetDetailScreen(assetId: id)));
          }
        },
      ),
    );
  }
}

class MyAssetsScreen extends StatelessWidget {
  const MyAssetsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Assets')),
      body: StreamBuilder<QuerySnapshot>(
        stream: db.collection('transactions')
            .where('buyerId', isEqualTo: auth.currentUser!.uid)
            .where('status', isEqualTo: 'completed')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final txns = snapshot.data!.docs;
          return ListView.builder(
            itemCount: txns.length,
            itemBuilder: (context, i) {
              final txn = txns[i].data()! as Map<String, dynamic>;
              return FutureBuilder<DocumentSnapshot>(
                future: db.collection('assets').doc(txn['assetId']).get(),
                builder: (context, assetSnap) {
                  if (!assetSnap.hasData) return const ListTile(title: Text('Loading...'));
                  final asset = assetSnap.data!.data()! as Map<String, dynamic>;
                  return ListTile(
                    leading: asset['images'] != null && asset['images'].isNotEmpty
                        ? Image.memory(base64Decode(asset['images'][0]), width: 50)
                        : const Icon(Icons.image),
                    title: Text(asset['title']),
                    trailing: IconButton(
                      icon: const Icon(Icons.picture_as_pdf),
                      onPressed: () async {
                        final pdf = pw.Document();
                        pdf.addPage(pw.Page(
                            build: (ctx) => pw.Center(
                                child: pw.Text('Ownership Certificate\n${asset['title']}\nOwner: ${auth.currentUser!.email}'))));
                        final dir = await getTemporaryDirectory();
                        final file = File('${dir.path}/cert.pdf');
                        await file.writeAsBytes(await pdf.save());
                        await Share.shareXFiles([XFile(file.path)]);
                      },
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            await auth.signOut();
            if (!context.mounted) return;
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (r) => false);
          },
          child: const Text('Logout'),
        ),
      ),
    );
  }
}

class PDFViewerScreen extends StatelessWidget {
  final File file;
  const PDFViewerScreen({super.key, required this.file});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Document')), body: PDFView(filePath: file.path));
  }
}